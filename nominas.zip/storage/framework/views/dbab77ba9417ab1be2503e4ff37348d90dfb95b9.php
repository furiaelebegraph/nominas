<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel alineado_centro">
                <?php if($errors->any()): ?>
                <h4><?php echo e($errors->first()); ?></h4>
                <?php endif; ?>
               <?php if(session('mensaje')): ?>
                    <div class="alert alert-success">
                            <strong><?php echo e(session('mensaje')); ?></strong> 
                    </div>
               <?php endif; ?>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/seller_login')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="row justify-content-center">
                            
                            <div class="col-12 form-group<?php echo e($errors->has('correo') ? ' has-error' : ''); ?>">
                                                        <label for="correo" class="col-md-4 control-label">E-Mail</label>

                                                        <div class="col-md-6">
                                                            <input id="correo" type="correo" class="form-control" name="correo" value="<?php echo e(old('correo')); ?>" required autofocus>

                                                            <?php if($errors->has('correo')): ?>
                                                                <span class="help-block">
                                                                    <strong><?php echo e($errors->first('correo')); ?></strong>
                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-12 form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                                        <label for="password" class="col-md-4 control-label">Password</label>

                                                        <div class="col-md-6">
                                                            <input id="password" type="password" class="form-control" name="password" required>

                                                            <?php if($errors->has('password')): ?>
                                                                <span class="help-block">
                                                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>



                                                    <div class="col-12 form-group p-t-20">
                                                        <div class="col-md-12">
                                                            <button type="submit" class="btn_pedorro btn-default">
                                                                Inicar Sesión
                                                            </button>

                                                        </div>
                                                    </div>                        
                                                    <div class="col-12 form-group  alineado_centro">
                                                        <div class="col-md-12">

                                                            <a class="btn btn-link" href="<?php echo e(url('/seller_password/reset')); ?>">
                                                                ¿Olvidaste tu Password?
                                                            </a>
                                                        </div>
                                                    </div>


                        </div>

                        
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('seller.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>