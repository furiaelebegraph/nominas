<?php $__env->startSection('content'); ?>

<div class="centrado_900">
    <section class="row justify-content-center align-items-center  alineado_centro">
        <div class="col-11 col-sm-8">
            <h1>
                Crear Nomina
            </h1>
            <a href="<?php echo url('nomina'); ?>" class = 'btn btn-success'><i class="fa fa-home"></i>VER LAS NOMINAS</a>
    <a href="<?php echo url('/home'); ?>" class = 'btn btn-primary'><i class="fa fa-home"></i> Panel Administrador</a>
            <br>
            <form class="form-horizontal m-t-30" role="form" method="POST" action="<?php echo e(url('/nomina')); ?>" enctype="multipart/form-data" >
                <?php echo e(csrf_field()); ?>

                <div class="form-group<?php echo e($errors->has('seller_id') ? ' has-error' : ''); ?>">
                    <label for="seller_id" class="col-md-12 control-label">Colaborador</label>
                    
                    <div class="col-12">
                        <select id='seller_id' class="form-control" name="seller_id">
                            <option value="" selected disabled style="display:none">Seleciona una colaborador</option>
                            <?php $__currentLoopData = $selers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colaborador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($colaborador->id); ?>"><?php echo e($colaborador->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <?php if($errors->has('seller_id')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('seller_id')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('fecha') ? ' has-error' : ''); ?>">
                    <label for="fecha" class="col-md-12 control-label">FECHA</label>

                    <div class="col-12">
                        <input type="date" class="form-control" name="fecha" value="<?php echo e(old('fecha')); ?>" required autofocus>

                        <?php if($errors->has('fecha')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('fecha')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('pdf') ? ' has-error' : ''); ?>">
                    <label for="pdf" class="col-md-12 control-label">PDF</label>

                    <div class="col-12">
                        <input id="pdf" type="file" class="form-control" name="pdf" value="<?php echo e(old('pdf')); ?>" required>

                        <?php if($errors->has('pdf')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('pdf')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('xml') ? ' has-error' : ''); ?>">
                    <label for="xml" class="col-md-12 control-label">XML</label>

                    <div class="col-12">
                        <input id="xml" type="file" class="form-control" name="xml" value="<?php echo e(old('xml')); ?>" required>

                        <?php if($errors->has('xml')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('xml')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>



                <div class="form-group">
                    <div class="col-md-12">
                        <button type="submit" class="btn_pedorro btn-default">
                            Registrar
                        </button>
                    </div>
                </div>
            </form>
        
        </div>
    </section>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>