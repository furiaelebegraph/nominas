<?php $__env->startSection('title','Index'); ?>
<?php $__env->startSection('content'); ?>

<div class="centrado_900">
<section class="row justify-content-center align-items-center">
    <div class="col-11 col-sm-8">
    <h1>
        Colaboradores Index
    </h1>
    <a href='<?php echo url("seller"); ?>/create' class = 'btn btn-success'><i class="fa fa-plus"></i> CREAR COLABORADOR</a>
    <a href="<?php echo url('/home'); ?>" class = 'btn btn-primary'><i class="fa fa-home"></i> Panel Administrador</a>
    <br>
    <?php if(session()->has('mensaje')): ?>
        <div class="alert alert-primary"> 
            <?php echo session('mensaje'); ?>

        </div>
    <?php endif; ?>
    <br>
    <table class = "table table-striped table-bordered table-hover" style = 'background:#fff'>
        <thead>
            <th>Coloaborador</th>
            <th>Correo</th>
            <th>actions</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colaboradores): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo $colaboradores->nombre; ?></td>
                <td><?php echo $colaboradores->correo; ?></td>
                <td>
                    <form action="<?php echo e(route('seller.destroy', ['id' => $colaboradores->id])); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                        <div class="form-group">
                            <button type="submit" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i> Eliminar</button>
                        </div>
                    </form>
                    <a href="<?php echo e(route('seller.edit', $colaboradores->id)); ?>" class = 'viewEdit btn btn-primary btn-xs'><i class = 'fa fa-edit'> edit</i></a>
                    <a href='#' class = 'viewShow btn btn-warning btn-xs' data-link = '/seller/<?php echo $colaboradores->id; ?>'><i class = 'fa fa-eye'> info</i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </tbody>
    </table>
    <?php echo $sellers->render(); ?>


</div>
</section>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>