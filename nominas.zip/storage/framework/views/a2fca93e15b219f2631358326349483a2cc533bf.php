<?php $__env->startSection('title','Edit'); ?>
<?php $__env->startSection('content'); ?>

<section class="row justify-content-center align-items-center">
    <div class="col-11 col-sm-8">
    <h1>
        Edit nomina
    </h1>
    <a href="<?php echo url('nomina'); ?>" class = 'btn btn-primary'><i class="fa fa-home"></i> Nomina Index</a>
    <br>
    <form method = 'POST' action = '<?php echo url("nomina"); ?>/<?php echo $nomina->id; ?>/update' enctype="multipart/form-data"> 
            <?php echo e(csrf_field()); ?>

            <div class="form-group<?php echo e($errors->has('seller_id') ? ' has-error' : ''); ?>">
                <label for="seller_id" class="col-md-4 control-label">Colaborador</label>
                
                <div class="col-md-6">
                    <select id='seller_id' class="form-control" name="seller_id">
                        <option selected="selected" value="<?php echo e($nomina->seller_id); ?> selected disabled style="display:none">$nomina->seller->nombre</option>
                        <?php $__currentLoopData = $selers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colaborador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($colaborador->id); ?>"><?php echo e($colaborador->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <?php if($errors->has('seller_id')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('seller_id')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group<?php echo e($errors->has('fecha') ? ' has-error' : ''); ?>">
                <label for="fecha" class="col-md-4 control-label">FECHA</label>

                <div class="col-md-6">
                    <input type="date" class="form-control" name="fecha" value="<?php echo $nomina->fecha; ?>" autofocus>

                    <?php if($errors->has('fecha')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('fecha')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('pdf') ? ' has-error' : ''); ?>">
                <label for="pdf" class="col-md-4 control-label">PDF</label>

                <div class="col-md-6">
                    <input id="pdf" type="file" class="form-control" name="pdf" value="<?php echo $nomina->xml; ?>">

                    <?php if($errors->has('pdf')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('pdf')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group<?php echo e($errors->has('xml') ? ' has-error' : ''); ?>">
                <label for="xml" class="col-md-4 control-label">XML</label>

                <div class="col-md-6">
                    <input id="xml" type="file" class="form-control" name="xml" value="<?php echo e(old('xml')); ?>" required>

                    <?php if($errors->has('xml')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('xml')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group">
                <div class="col-md-6 col-md-offset-4">
                    <button class = 'btn btn-success' type ='submit'><i class="fa fa-floppy-o"></i> Update</button>
                </div>
            </div>
    </form>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>