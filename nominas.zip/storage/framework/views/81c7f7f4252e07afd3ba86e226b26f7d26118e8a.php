<?php $__env->startSection('title','Index'); ?>
<?php $__env->startSection('content'); ?>

<div class="centrado_900">
<section class="row justify-content-center align-items-center">
    <div class="col-11 col-sm-8">
    <h1>
        Nomina Index
    </h1>
    <a href='<?php echo url("nomina"); ?>/create' class = 'btn btn-success'><i class="fa fa-plus"></i> CREAR NOMINA</a>
    <a href="<?php echo url('/home'); ?>" class = 'btn btn-primary'><i class="fa fa-home"></i> Panel Administrador</a>
    <br>
    <br>
    <?php if(session()->has('mensaje')): ?>
        <div class="alert alert-primary"> 
            <?php echo session('mensaje'); ?>

        </div>
    <?php endif; ?>
    <table class = "table table-striped table-bordered table-hover" style = 'background:#fff'>
        <thead>
            <th>fecha</th>
            <th>Colaborador</th>
            <th>actions</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $nominas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tr>
                <td><?php echo $nomina->fecha; ?></td>
                <td><?php echo $nomina->seller['nombre']; ?></td>
                <td>
                    <form action="<?php echo e(route('nomina.destroy', ['id' => $nomina->id])); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                        <div class="form-group">
                            <button type="submit" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i> Eliminar</button>
                        </div>
                    </form>
                    <a href = "<?php echo e(route('nomina.edit', $nomina->id)); ?>" class = 'viewEdit btn btn-primary btn-xs'><i class = 'fa fa-edit'> edit</i></a>
                    <a href = '#' class = 'viewShow btn btn-warning btn-xs' data-link = '/nomina/<?php echo $nomina->id; ?>'><i class = 'fa fa-eye'> info</i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </tbody>
    </table>
    <nav aria-label="Page navigation example">
    <?php echo $nominas->render(); ?>

    </nav>

</div>
</section>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>