<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="panel">
                <div class="panel-heading">Panel Administrador</div>

                <?php if(session()->has('mensaje')): ?>
                    <div class="alert alert-primary"> 
                        <?php echo session('mensaje'); ?>

                    </div>
                <?php endif; ?>
                <div class="panel-body">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-12 col-sm-6">
                            <div class="card">
                              <div class="card-body">
                                <h5 class="card-title">Crear Nomina</h5>
                                <p class="card-text">Genera una nueva nomina para un colaborador</p>
                                <a href=" <?php echo e(url('nomina/create')); ?> " class = 'btn btn-primary'>Crear Nomina</a>
                              </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="card">
                              <div class="card-body">
                                <h5 class="card-title">Crear Colaborador</h5>
                                <p class="card-text">Crea una nueva nueva cuenta</p>
                                <a href=" <?php echo e(url('seller/create')); ?> " class = 'btn btn-primary'>Crear Colaborador</a>
                              </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center m-t-50">
                    <div class="col-11 col-sm-12">
                        <table class = "table table-hover" style = 'background:#fff'>
                            <thead>
                                <th>#</th>
                                <th>fecha</th>
                                <th>colaborador</th>
                                <th>actions</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $nominis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <tr>
                                    <td><?php echo $nomina->id; ?></td>
                                    <td><?php echo $nomina->fecha; ?></td>
                                    <td><?php echo $nomina->seller['nombre']; ?></td>
                                    <td>
                                        <form action="<?php echo e(route('nomina.destroy', ['id' => $nomina->id])); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            <div class="form-group">
                                                <button type="submit" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i> Eliminar</button>
                                            </div>
                                        </form>
                                        <a href = "<?php echo e(route('nomina.edit', $nomina->id)); ?>" class = 'viewEdit btn btn-primary btn-xs'><i class = 'fa fa-edit'> edit</i></a>
                                        <a href = '#' class = 'viewShow btn btn-warning btn-xs' data-link = '/nomina/<?php echo $nomina->id; ?>'><i class = 'fa fa-eye'> info</i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </tbody>
                        </table>
                        <nav aria-label="Page navigation example">
                           <?php echo e($nominis->links()); ?>

                        </nav>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>