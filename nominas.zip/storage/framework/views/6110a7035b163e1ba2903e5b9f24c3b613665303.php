<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center align-items-center">
        <div class="col-md-8">
            <div class="row justify-content-center panel panel-success">
                <div class="col-12">
                    <?php if($nominis->count() > 0): ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Fecha</th>
                                <th scope="col">PDF</th>
                                <th scope="col">XML</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $nominis->nominas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supernomina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($supernomina->id); ?> </td>
                                <td> <?php echo e($supernomina->fecha); ?> </td>
                                <td> <a download href="<?php echo e(asset('img/'.$supernomina->pdf)); ?>">Descargar PDF</a></td>
                                <td> <a download href="<?php echo e(asset('img/'.$supernomina->xml)); ?>"> Descargar XML</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                        <?php else: ?>
                        <div class="panel-heading">
                            No sea encontrado ningun elemento
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('seller.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>