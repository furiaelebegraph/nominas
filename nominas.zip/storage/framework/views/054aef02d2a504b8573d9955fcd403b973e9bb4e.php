<?php $__env->startSection('title','Edit'); ?>
<?php $__env->startSection('content'); ?>

<div class="centrado_900">
<section class="row justify-content-center align-items-center">
    <div class="col-11 col-sm-8">
    <h1>
        Editar Colaboradores
    </h1>
    <a href="<?php echo url('seller'); ?>" class = 'btn btn-danger'><i class="fa fa-home"></i> Index Colaboradores </a>
    <a href="<?php echo url('/home'); ?>" class = 'btn btn-primary'><i class="fa fa-home"></i> Panel Administrador</a>
    <br>
<form class="form-horizontal" role="form" method="POST" action='<?php echo url("seller"); ?>/<?php echo $colaborador->id; ?>/update'>
        <?php echo e(csrf_field()); ?>


        <div class="form-group<?php echo e($errors->has('nombre') ? ' has-error' : ''); ?>">
            <label for="nombre" class="col-md-4 control-label">Nombre</label>

            <div class="col-md-6">
                <input id="nombre" type="text" class="form-control" name="nombre" value="<?php echo $colaborador->nombre; ?>" required autofocus>

                <?php if($errors->has('nombre')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('nombre')); ?></strong>
                </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group<?php echo e($errors->has('correo') ? ' has-error' : ''); ?>">
            <label for="correo" class="col-md-4 control-label">Correo Electronico</label>

            <div class="col-md-6">
                <input id="correo" type="email" class="form-control" name="correo" value="<?php echo $colaborador->correo; ?>" required>

                <?php if($errors->has('correo')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('correo')); ?></strong>
                </span>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group<?php echo e($errors->has('telefono') ? ' has-error' : ''); ?>">
            <label for="telefono" class="col-md-4 control-label">Telefono</label>

            <div class="col-md-6">
                <input id="telefono" type="tel" class="form-control" name="telefono" value="<?php echo $colaborador->telefono; ?>" required>

                <?php if($errors->has('telefono')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('telefono')); ?></strong>
                </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group<?php echo e($errors->has('direccion') ? ' has-error' : ''); ?>">
            <label for="direccion" class="col-md-4 control-label">Direccion</label>

            <div class="col-md-6">
                <input id="direccion" type="text" class="form-control" name="direccion" value="<?php echo $colaborador->direccion; ?>" required>

                <?php if($errors->has('direccion')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('direccion')); ?></strong>
                </span>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group<?php echo e($errors->has('nss') ? ' has-error' : ''); ?>">
            <label for="nss" class="col-md-4 control-label">Numero de Seguro Social</label>
            <div class="col-md-6">
                <input id="nss" type="text" class="form-control" name="nss" value="<?php echo $colaborador->nss; ?>" required>

                <?php if($errors->has('nss')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('nss')); ?></strong>
                </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <div class="col-md-6 col-md-offset-4">
                <button type="submit" class="btn btn-success">
                    Registrar
                </button>
            </div>
        </div>
</form>
</div>
</section>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>