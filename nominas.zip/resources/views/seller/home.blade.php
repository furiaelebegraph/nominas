@extends('seller.layouts')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-success">
                <div class="panel-heading">Seller's Dashboard</div>

                <div class="panel-body">
                    Greetings.. Seller
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
