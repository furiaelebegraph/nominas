##Example of Multi Auth in Laravel 5.4
